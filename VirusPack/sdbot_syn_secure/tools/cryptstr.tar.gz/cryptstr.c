#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int cryptkey = 2667;

char * decryptstr(char *str, int strlenx);

int main()
{
   char foo[26];
   int len,q;
   
   printf("CryptKey:");
   gets(foo);
   cryptkey = atoi(foo);
   
   do
     {
	printf("\nEnter phrase to be encrypted:");
	gets(foo);
	if( ! (len = strlen(foo))) break;
	decryptstr(foo,len + 1);
	for( q = 0; q < len +1; q++)
	  {
	     printf("\\x%02x", (unsigned char) foo[q]);
	  }
     } while(1);
   
}

char * decryptstr(char *str, int strlenx) 
{
   short i;
   for (i = 0; i < strlenx; i++) str[i] = str[i] ^ (cryptkey + (i * (cryptkey % 10) + 1));
   return str;
}

