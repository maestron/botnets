#include <stdio.h>
#include <strings.h>


int main()
{
	char foo[200];
	char salt[10];

	printf("\nPASSWORD:");
	gets(foo);
	printf("\nSALT:");
	gets(salt);

	printf("\nMD5PASWORD: %s\n",crypt_md5(foo,salt));

}
